# 3D Audio Visualizer

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/1NxAxhUVn38/0.jpg)](https://www.youtube.com/watch?v=1NxAxhUVn38)

> <a href="https://3d-audio-visualizer.vercel.app/">Live version here</a>

[![Edit 3d-audio-visualizer](https://codesandbox.io/static/img/play-codesandbox.svg)](https://codesandbox.io/s/github/DaniloArantesF/3d-audio-visualizer/tree/main/?fontsize=14&hidenavigation=1&theme=dark)

### Setup
Clone this repository and install dependencies using the package manager of your choice.
Starting the live server is as simple as:
```bash
yarn dev
```

### To-Dos
- [ ] Add GUI to control scene parameters

### Known bugs
* Audio doesn't work on mobile

<!-- [⬆ Voltar ao topo](#3d-audio-visualizer)<br> -->